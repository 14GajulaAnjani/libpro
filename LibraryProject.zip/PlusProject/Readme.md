+ Project - AI Landing Page

Built with HTML and the Tailwind CSS CDN only. No build step, no other frameworks, no custom fonts.

How to run
Open index.html in a browser (internet needed for the Tailwind CDN). Keep dashboard.svg in the same folder.

What is included
- Sticky navbar: + Project logo, links (Product, Solutions, Resources, Pricing, Log in), Get AI free button
- Hero with light orange to white gradient (bg-gradient-to-b from-orange-100 to-white)
- Centered headline: Write, plan, share. With AI at your side.
- Two CTA buttons (Get AI free, Request a demo) placed using relative and absolute positioning
- Dashboard preview image centered with absolute positioning inside a relative container
- Three floating cards (Tasks, Project Status, Team Activity) using absolute, z-index and shadow utilities
- Fixed chat widget at bottom-right: fixed bottom-6 right-6 z-50
